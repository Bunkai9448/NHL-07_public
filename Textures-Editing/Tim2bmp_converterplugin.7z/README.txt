Tim2bmp Converter Tool (exe file by gnie)
https://www.romhacking.net/utilities/661/

Photoshop plugin (credits unknown)
tm2xFormat.8bi