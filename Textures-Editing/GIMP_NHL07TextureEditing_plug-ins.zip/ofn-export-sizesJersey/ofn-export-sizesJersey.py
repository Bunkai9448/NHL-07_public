#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GIMP plugin to expor an image under different sizes

# (c) Ofnuts 2021
#
#   History:
#
#   v0.0: 2021-02-24 First published version
#   v0.1: 2021-02-27 Add non-square shapes

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published
#   by the Free Software Foundation; either version 3 of the License, or
#   (at your option) any later version.
#
#   This very file is the complete source code to the program.
#
#   If you make and redistribute changes to this code, please mark it
#   in reasonable ways as different from the original version. 
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   The GPL v3 licence is available at: https://www.gnu.org/licenses/gpl-3.0.en.html

import sys,os,os.path,traceback,re
from gimpfu import *

debug='OFN_DEBUG' in os.environ
  
def trace(format,*args):
    if debug:
        print format % args

def parseSizes(s):
    specs=re.split(u'[*x×]',unicode(s))
    try:
        if len(specs)==1:
            return int(specs[0]),int(specs[0])
        elif len(specs)==2:
            return int(specs[0]),int(specs[1])
        else:
            raise Exception()
    except:
        raise Exception("Invalid size format: %s" % s)

def exportSizes(image,sizeString,namePattern,directory):

    try:
        if not image.filename:
            imageName='Size'
        else:
            imageName,_=os.path.splitext(os.path.basename(image.filename))
        if image.filename and not directory:
            directory=os.path.dirname(image.filename)
        if not directory:
            directory='.'
        trace('Exporting to %s', directory)

        sizes=[]
        try: 
            sizes=[parseSizes(s) for s in re.split("[, ]*",sizeString) if s]
        except ValueError as e:
            trace('Format exception: %s',e)
            raise Exception('Invalid number format in "%s"' % sizeString) 
        if not sizes:
            raise Exception('No size specified in "%s"' % sizeString) 
            
        sizesCount=len(sizes)
        formatValues={}
        formatValues['imageName']=imageName
        formatValues['count']=sizes
        pdb.gimp_image_convert_indexed(image,0,0,256,False,False,"")
        for i,size in enumerate(sizes):
            w,h=size
            formatValues['width']=w
            formatValues['height']=h
            formatValues['num0']=i
            formatValues['num1']=i+1
    
            try:
                saveName=namePattern.format(**formatValues)
            except KeyError as e:
                raise Exception('No formatting variable called "%s"' % e.args[0])        
            filename=os.path.join(directory,saveName)

            saveLayer=pdb.gimp_layer_new_from_visible(image,image, saveName)
            image.add_layer(saveLayer,0)
            saveLayer.scale(w,h,False)
            pdb.gimp_file_save(image,saveLayer,filename,filename)
            image.remove_layer(saveLayer)
            
    except Exception as e:
        pdb.gimp_message(e.args[0])
        print traceback.format_exc()
    
### Registrations
author='Ofnuts'
year='2021'
exportMenu='<Image>/File/Export/'
exportDesc='Export all for jersey sizes'
whoiam='\n'+os.path.abspath(sys.argv[0])

register(
    'ofn-export-sizes-Jerseys',
    exportDesc,exportDesc+whoiam,author,author,year,exportDesc+'...',
    '*',
    [
        (PF_IMAGE,      'image',        'Input image', None),
        (PF_STRING,     'sizes',        'Sizes',   '4,8,16,32,64,128,256'),
        (PF_STRING,     'namePattern',  'Export name',   '{imageName}-{width}-{height}.png'),
        (PF_DIRNAME,    'directory',    'Directory',   ''),
    ],
    [],
    exportSizes,
    menu=exportMenu
)
    
main()
