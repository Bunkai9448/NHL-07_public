# README

## Ini Files contributors

Lorak
RetroIGRUN

## How to, by Lorak

**General steps to edit game textures and logos**

There are two places to look at, PSP_GAME-USDIR-fe and PSP_GAME-USDIR-gamedata. From now on, we call it fe and gamedata respectively. Get the tools from github or the links below.

1) Select the assets -mainly .viv and .big files- to edit from fe and gamedata. An advice is to work on the files from one location to then go on to the next one. For example, work on the files from fe and then gamedata. 

Typically, you get jerapt.viv, tlogoap.viv from fe and arenaXXX.big -here, XXX is a placeholder for a team-, IceTxtrs.big and jerseys.viv from gamedata. Of course, there are more files to work on.

2) Extract the contents of the files chosen in 1 via big gui. Almost all textures in this game are in .msh files.

3) Get the .ini files from github and open your .msh file in Console Texture Explorer, export it as .tm2 files. 

4) Open those. tm2 files in Game Graphic Studio (GGS). Edit it there. This could be very annoying -_a pain in the ass, I would say_ ?? -. Save the file. Not recommended.

_As an alternative, edit the .tm2 files in Rainbow https://github.com/marco-calautti/Rainbow. First, open a .tm2 file and export it. You get a .png and a .xml file. Just edit the .png in your favorite software. GIMP, Photoshop or any other. Save your changes without changing the file name. Go back to Rainbow and import the .xml file. It will load the edited .png too._  Rainbow seems to be really user friendly.

5) Import the updated .tm2 file from 4 to Console Texture Explorer to actually edit the .msh file. Save the updated .msh file.

6) Import the .msh file in big gui and rebuild - to save it- your .viv or .big file. Run BHImport from USRDIR to fix the headers of the edited files. Finally, rebuild your iso in UMDGen.

 Always have a backup of the stock files.

If you have problems, ask for help here.
Start editing and have fun!